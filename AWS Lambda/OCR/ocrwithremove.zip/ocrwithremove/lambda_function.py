"""
Your module description
"""
import json

import requests

from aip import AipOcr


def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        return False


import re


def number_str(string1):
    if re.match("^[0-9.\ ]*$", string1):
        return True

import sys
import logging
import pymysql
#rds settings
rds_host  = "mydb.ce51ycoxei5f.us-east-2.rds.amazonaws.com"
name = "jerry"
password ="12345678"
db_name = "mydb"

logger = logging.getLogger()
logger.setLevel(logging.INFO)



try:
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
except:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    sys.exit()

sqllist=[]
with conn.cursor() as cur:
    cur.execute("select foodname,DATE_FORMAT(startdate, '%d/%m/%Y'),CAST(price as CHAR(50)) from food WHERE DATE(startdate) = CURDATE()")
for row in cur:
    sqllist.append(row)
conn.commit()
    
sqllist2=[]

for i in range(len(sqllist)):
    sqllist2.append([])
    sqllist2[i].append(sqllist[i][0].replace('_', ' '))
    sqllist2[i].append(sqllist[i][1])
    sqllist2[i].append(float(sqllist[i][2]))
    
sqllist4=[]
with conn.cursor() as cur2:
    cur2.execute("select count(distinct(f.uid)) as countid,f.foodname ,c.categoryname ,count(c.categoryname) from food f , category c where f.cid=c.cid  group by f.foodname,c.categoryname")
for row in cur2:
    sqllist4.append(row)
    
    


sqllist5=[]
for i in sqllist4:
    if i[0]>=5 and i[3]>=5:
        sqllist5.append(i[1:3])
        
sqllist6={}
tmpfoodlist=[]
for i in range(len(sqllist5)):
    sqllist6[sqllist5[i][0].replace('_', ' ')]=sqllist5[i][1]
    
        
    

        

""" APPID AK SK """
APP_ID = '15882012'
API_KEY = 'LnPku2VRSVXCLoVTBO3OWGSp'
SECRET_KEY = 'GHEnu7n9RL4GZTsFuyjlEnVD4cVcEdiC'
url1 = "https://i.ibb.co/hHJrv38/mmexport1554194803352.jpg"
client = AipOcr(APP_ID, API_KEY, SECRET_KEY)

def charposition(string, char):
    pos = [] #list to store positions for each 'char' in 'string'
    for n in range(len(string)):
        if string[n] == char:
            pos.append(n)
    return pos
import requests


options = {}
""" select language  """
options["language_type"] = "ENG"
""" detect photo angle"""
options["detect_direction"] = "true"
""" language detect """
options["detect_language"] = "false"
""" probability """
options["probability"] = "false"

""" ocr with options """
#result = client.basicGeneral(image, options)

foodlist=['herb', 'oranges','salt', 'stock', 'cube', 'chemical', 'cooking', 'ingredient','lettuce', 'gelatine', 'cereal', 'flour', 'starch', 'potato', 'product', 'essence', 'yeast', 'beer', 'alcohol', 'spirit', 'cider', 'wine', 'variety', 'style', 'beverage', 'flavouring', 'water', 'milk', 'coffee', 'powder', 'concentrate', 'cordial', 'fruit', 'drink', 'berries','juice', 'cola', 'energy', 'tea', 'tap', 'savoury', 'biscuit', 'rice', 'cake', 'wheat', 'plain', 'kj', 'bread', 'sweet', 'chocolate', 'cream', 'chip', 'roll', 'fortification', 'wholemeal', 'brown', 'grain', 'bun', 'scroll', 'rye', 'muffin', 'breakfast', 'corn', 'sugar', 'nut', 'mix', 'type', 'slice', 'sponge', 'doughnut', 'pancake', 'crepe', 'drop', 'scone', 'dessert', 'rock', 'fraction', 'porridge', 'oat', 'seed', 'dish', 'g', 'legume', 'burger', 'sandwich', 'pizza', 'noodle', 'instant', 'pastry', 'pie', 'envelope', 'egg', 'eggs', 'dressing', 'fat', 'mayonnaise', 'gravy', 'sauce', 'paste', 'fish', 'seafood', 'beef', 'tomato', 'vinegar', 'cheese', 'camembert', 'brie', 'surface', 'cottage', 'substiuet', 'ice', 'content', 'bar', 'stick', 'cone', 'confection', 'gelato', 'sorbet', 'cow', 'fluid', 'whole', 'skim', 'breast', 'custard', 'yoghurt', 'meat', 'butter', 'blend', 'margarine', 'spread', 'phytosterols', 'oil', 'chicken', 'folate', 'apple', 'stone', 'banana', 'berry', 'mixture', 'group', 'citrus', 'peel', 'lemon', 'lime', 'peach', 'orange', 'nectarine', 'pear', 'pineapple', 'mature', 'pulse', 'pea', 'veal', 'lamb', 'mutton', 'game', 'pork', 'poultry', 'meatloaf', 'reptile', 'kangaroo', 'liver', 'bacon', 'frankfurt', 'saveloy', 'ham', 'sausage', 'salami', 'coconut', 'peanut', 'fin', 'mollusc', 'crustacea', 'muesli', 'coating', 'confectionery', 'snack', 'crisp', 'soup', 'filling', 'addition', 'pickle', 'chutney', 'jam', 'conserve', 'honey', 'syrup', 'stalk', 'root', 'cabbage', 'brassica', 'broccoli', 'broccolini', 'carrot', 'leaf', 'vegetable', 'onion', 'leek', 'mushroom', 'seaweed', 'sprout', 'squash', 'zucchini', 'wild', 'aroma', 'bagel', 'batter', 'beans', 'broth', 'candy', 'caramel', 'caviar', 'chili', 'cobbler', 'cocoa', 'cookie', 'croissant', 'crumble', 'cuisine', 'curd', 'entree', 'filet', 'glaze', 'grill', 'hamburger', 'ketchup', 'kitchen', 'lard', 'liquor', 'marinade', 'mayo', 'mousse', 'olive', 'omelette', 'pan', 'plate', 'pot', 'poutine', 'pudding', 'raclette', 'recipe', 'salad', 'salsa', 'seasoning', 'skillet', 'soda', 'soy', 'spice', 'steak', 'stew', 'tartar', 'taste', 'toast', 'waffle', 'wok', 'yogurt', 'apricot', 'avocado', 'cantaloupe', 'cherry', 'citron', 'fig', 'grape', 'guava', 'kiwi', 'mango', 'melon', 'mulberry', 'papaya', 'plum', 'prune', 'raisin', 'raspberry', 'tangerine', 'alligator', 'bison', 'buffalo', 'caribou', 'duck', 'elk', 'goat', 'pheasant', 'quail', 'rabbit', 'turkey', 'venison', 'yak', 'baguette']

expirydate={'baking':180,'vegetable':6,'fruit':5,'seafood':4,'dairy':8,'meat':5,'dairy_product':45,'protein':28,'drink':14,'others':14}

dairy=['condensed milk', 'cottage or farmer’s cheese', 'cream', 'evaporated milk', 'fluid milk', 'pudding', 'reconstituted nfdm', 'cream', 'yogurt']

fruit=['apple', 'apricot', 'oranges','avocado', 'banana', 'berry', 'lettuce','cantaloupe', 'cherry', 'citron', 'citrus', 'coconut', 'date', 'fig', 'grape', 'guava', 'kiwi', 'lemon', 'lime', 'mango', 'melon', 'mulberry', 'nectarine', 'papaya', 'peach', 'pear', 'pineapple', 'plum', 'prune', 'raisin', 'raspberry', 'tangerine','berries']

baking=['baking powder', 'barley', 'bread crumbs', 'bulgar', 'cereal', 'chocolate, baking', 'cornstarch', 'flour', 'weat', 'honey syrup', 'noodles', 'olive oil', 'pasta', 'rice', 'sugar, brown', 'wheat']

vegetable=['artichokes', 'asparagus', 'beets', 'broccoli', 'brussels sprouts', 'cabbage', 'carrots', 'cauliflower', 'celery', 'corn', 'cucumbers', 'eggplant', 'green beans', 'greens', 'jicama', 'kohlrabi', 'lettuce and salad greens', 'lima beans', 'mushrooms', 'okra', 'onions, green', 'parsley', 'peas', 'peppers', 'radishes', 'squash, winter', 'squash, summer', 'tomatillos', 'tomatoes']

dairy_product=['margarine', 'butter', 'cheese']

egg=['egg','eggs']

drink=['tea','coke','juice','water']

meat=['alligator', 'beef', 'bison', 'buffalo', 'caribou', 'chicken', 'duck', 'elk', 'goat', 'lamb', 'pheasant', 'pork', 'quail', 'rabbit', 'turkey', 'veal', 'venison', 'yak']

fish=['amberjack', 'anchovy', 'angler', 'ayu', 'barbel', 'barracuda', 'bass', 'betta', 'blowfish', 'bocaccio', 'burbot', 'carp', 'cobbler', 'cod', 'eel', 'flounder', 'grouper', 'haddock', 'halibut', 'herring', 'mackerel', 'marlin', 'mullet', 'perch', 'pollock', 'salmon', 'sardine', 'scallop', 'shark', 'snapper', 'sole', 'tilapia', 'trout', 'tuna']


symbols=['`','~','!','@','#','$','%','^','&','[',']','*','-',':']





import sys
import logging
import pymysql.cursors
import time
from datetime import datetime
now = datetime.now()
date_time = now.strftime("%m/%d/%Y")
#rds settings
rds_host  = "mydb.ce51ycoxei5f.us-east-2.rds.amazonaws.com"
name = "jerry"
password ="12345678"
db_name = "mydb"

logger = logging.getLogger()
logger.setLevel(logging.INFO)






def lambda_handler(event,context):
    response = requests.get(event['url1'])
    image = response.content
    result = client.basicAccurate(image, options) 
    words_result = result['words_result']
    list1 = []
    for i in range(len(words_result)):
        list1.append(words_result[i]['words'])
        
        
        
    for i in range(len(list1)):
        tmpword=list1[i].strip()
        if re.match("^[A][ ][X]", tmpword):
            list1[i]=list1[i][3:]
        
        elif re.match("^[xX][xX]", tmpword):
            list1[i]=list1[i][2:]
            
        elif re.match("^[xX][ ]", tmpword):
            list1[i]=list1[i][2:]
            
            
    for i in range(len(list1)):
        for j in symbols:
        
            if j in list1[i]:
            
                list1[i]=list1[i].replace(j,"") 

    list2 = []
    for i in range(len(list1)):
        tmp = list1[i].lower()
        list2.append(tmp.split())
        
        

            

    list3 = []
    tmplist = []
    for i in range(len(list2)):
        list3.append([])
        for j in range(len(list2[i])):
            if list2[i][j] in foodlist:
                list3[i].append(list2[i][j])
                tmplist.append(i)

            elif len(list2[i])==1 and is_number(list2[i][j]) == True or list2[i][j] == '.':
                # print(list2[i][j])
                list3[i].append(list2[i][j])

        list3[i] = ' '.join(list3[i])
        
    
        
    for i in range(len(list3)):
        if number_str(list3[i])==True:
            tmp=charposition(list3[i], ' ')
            if len(tmp)==1:
                list3[i]= list3[i][:tmp[0]] + '.' + list3[i][tmp[0] + 1:]
                
    for i in range(len(list3)):
        if number_str(list3[i])==True:
            list3[i]=list3[i].replace(" ","")
      

    tmplist=list(dict.fromkeys(tmplist))
    
            
    aaa={}
    for i in tmplist:
        for j in list2[i]:
            if len(j)>=3 and len([s for s in dairy if j in s])>=1:
                aaa.setdefault(i, []).append('dairy')
            elif len(j)>=3 and len([s for s in vegetable if j in s])>=1:
                aaa.setdefault(i, []).append('vegetable')
            elif len(j)>=3 and len([s for s in meat if j in s])>=1:
                aaa.setdefault(i, []).append('meat')
            elif len(j)>=3 and len([s for s in fruit if j in s])>=1:
                aaa.setdefault(i, []).append('fruit')
            elif len(j)>=3 and len([s for s in dairy_product if j in s])>=1:
                aaa.setdefault(i, []).append('dairy_product')
            elif len(j)>=3 and len([s for s in egg if j in s])>=1:
                aaa.setdefault(i, []).append('protein')
            elif len(j)>=3 and len([s for s in baking if j in s])>=1:
                aaa.setdefault(i, []).append('baking')
            elif len(j)>=3 and len([s for s in fish if j in s])>=1:
                aaa.setdefault(i, []).append('seafood')
            elif len(j)>=3 and len([s for s in drink if j in s])>=1:
                aaa.setdefault(i, []).append('drink')
            
            else:
                aaa.setdefault(i, []).append('others')
        
            
    dict22={}
    for i in tmplist:
        tmp=aaa.get(i)
    #print(tmp)
        tmp2=[]
        for j in tmp:
            if j!='others':
                tmp2.append(j)
    
        if len(tmp2)>=1:
            dict22[i]=tmp2[0]
        else:
            dict22[i]='others'
    
    
        
    output=[]
    for i in tmplist:
        #tmp_food=re.sub('[0-9.]+', '',list3[i])
        tmp_food=list1[i]
        
        if re.match(r'^[A-z][ ]',tmp_food):
            tmp_food=tmp_food[0:1]+tmp_food[2:]
        tmp_number=re.search(r'[0-9][A-z][ ][A-z]',tmp_food)
        
        if tmp_number is not None:
            tmp_food=tmp_food[:tmp_number.end()-2]+tmp_food[tmp_number.end()-1:]
        
        list4 = {}
        if is_number(list3[i + 1]) == True :
            list4['Item']=tmp_food
            list4['price']=float(list3[i + 1])
            list4['expiry days']=expirydate[dict22[i]]
            list4['keyword']=list3[i]
            if tmp_food in sqllist6.keys():
                
                list4['category']=sqllist6[tmp_food]
            else:
                list4['category']=dict22[i]
                
            
            
            
        elif list3[i+1] == '' and is_number(list3[i + 2]) == True:
            list4['Item']=tmp_food
            list4['price']=float(list3[i + 2])
            list4['keyword']=list3[i]
            
            list4['expiry days']=expirydate[dict22[i]]
            if tmp_food in sqllist6.keys():
                
                list4['category']=sqllist6[tmp_food]
            else:
                list4['category']=dict22[i]
            
        
        if list4!={}:
            
            output.append(list4)
            
        
        
    output2=[]  
        
    for i in range(len(output)):
        for j in range(len(sqllist2)):
            if output[i]['Item'] !=sqllist2[j][0] and output[i]['price'] !=sqllist2[j][2] :
                output2.append(i)
                
    output2 = list(dict.fromkeys(output2))  
     
        
    output3=[]
    if len(output2)>=1:
        for i in output2:
            output3.append(output[i])
    else:
        output3=output
        
    output4=[]
    for i in range(len(output3)):
        if len(output3[i].keys())!=0 and output3[i]['Item']!='' and output3[i]['price']!='' and output3[i]['category']!='' and output3[i]['expiry days']!='':
            output4.append(output3[i])
    
        #json_data=json.dumps(output)

    return output4











