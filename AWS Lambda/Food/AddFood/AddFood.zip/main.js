var mysql = require('mysql');
var config = require('./config.json');
var pool  = mysql.createPool({
  host     : config.dbhost,
  user     : config.dbuser,
  password : config.dbpassword,
  database : config.dbname
});

exports.handler = (event,context,callback) => {
context.callbackWaitsForEmptyEventLoop = false;
pool.getConnection(function(err, connection) {
  var name = event.name;
  var uid = event.uid;
  var cid = event.cid;
  var lid = event.lid
  var start = event.start;
  var expire = event.expire;
  var price = event.price
  var food = [uid,cid,lid,name,start,expire,price];
  // Use the connection
  connection.query('INSERT INTO food(uid,cid,lid,foodname,startdate,expiredate,price,quantity,complete_Percent,keyword) values (?,?,?,?,?,?,?,"",0,"")', food,function (error, results, fields) {
    // And done with the connection.
    connection.release();
    // Handle error after the release.
    if (error) callback(error);
    else callback(null,results);
  });
});
};
