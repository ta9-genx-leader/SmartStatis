var mysql = require('mysql');
var config = require('./config.json');
var pool  = mysql.createPool({
  host     : config.dbhost,
  user     : config.dbuser,
  password : config.dbpassword,
  database : config.dbname
});

exports.handler = (event,context,callback) => {
context.callbackWaitsForEmptyEventLoop = false;
pool.getConnection(function(err, connection) {
  var price=event.price;
  var id=event.id;	 
  var food = [price,id]
  // Use the connection
  connection.query('UPDATE food SET price=? WHERE foodid=?',food ,function (error, results, fields) {
    // And done with the connection.
    connection.release();
    // Handle error after the release.
    if (error) callback(error);
    else callback(null,"success!");
  });
});
};