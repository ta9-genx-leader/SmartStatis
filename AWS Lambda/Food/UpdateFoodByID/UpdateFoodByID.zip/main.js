var mysql = require('mysql');
var config = require('./config.json');
var pool  = mysql.createPool({
  host     : config.dbhost,
  user     : config.dbuser,
  password : config.dbpassword,
  database : config.dbname
});

exports.handler = (event,context,callback) => {
context.callbackWaitsForEmptyEventLoop = false;
pool.getConnection(function(err, connection) {
  var id=event.id;
  var name=event.name;
  var price=event.price;
  var buy = event.buy;
  var location = event.location;
  var category = event.category;
  var expire = event.expire;
  var food = [name,buy,expire,price,category,location,id];
  // Use the connection
  connection.query('UPDATE food SET foodname=?,startdate=?,expiredate=?,price=?,cid=?,lid=? WHERE foodid=?;',food ,function (error, results, fields) {
    // And done with the connection.
    connection.release();
    // Handle error after the release.
    if (error) callback(error);
    else callback(null,"success!");
  });
});
};