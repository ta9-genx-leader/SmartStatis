import json

waste_per_house_hold={'ACT': 210,'ASUT': 202,'NSW': 210,'QLD': 222,'SA': 170, 'TAS': 178, 'VIC': 183,'WA': 203}
 
waste_cate={'Dairy and dairy product': 85,'baking': 93,'drinks': 70, 'fruit and vegetable': 187,'meat and fish': 136,'other': 270}
 
 
waste_person={'four or more': 63,'four person': 64,'single person': 119,'three person': 85,'two person': 83}

waste_per_person={'ACT': 82,'ASUT': 78,'NSW': 82,'QLD': 86,'SA': 70,'TAS': 74,'VIC': 70,'WA': 78}

def lambda_handler(event, context):
    # TODO implement
    return [waste_per_house_hold,waste_cate,waste_per_person,waste_person]


