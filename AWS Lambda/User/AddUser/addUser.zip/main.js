var mysql = require('mysql');
var config = require('./config.json');
var pool  = mysql.createPool({
  host     : config.dbhost,
  user     : config.dbuser,
  password : config.dbpassword,
  database : config.dbname
});

exports.handler = (event,context,callback) => {
context.callbackWaitsForEmptyEventLoop = false;
pool.getConnection(function(err, connection) {
  var fname=event.firstname;
  var lname=event.lastname;
  var email=event.email;
  var pwd=event.password;	 
  var newUser = [fname,lname,email,pwd]
  // Use the connection
  connection.query('INSERT Into user(firstname,lastname,email,password) values (?,?,?,?)',newUser ,function (error, results, fields) {
    // And done with the connection.
    connection.release();
    // Handle error after the release.
    if (error) callback(error);
    else callback(null,"success!");
  });
});
};
